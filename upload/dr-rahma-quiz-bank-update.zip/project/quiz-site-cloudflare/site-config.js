// Shared helpers used by every page. Backend lives on the same site under /api/*.

// NOTE: these deliberately do NOT throw on 4xx/5xx application errors (e.g. wrong
// password, validation failures) — the worker always replies with a JSON body like
// {error: "..."} in those cases, and callers check `.error` / `.ok` themselves.
// They only throw for genuine network failures (fetch() rejecting, or a response
// that isn't JSON at all), which callers catch to show a "check your connection" message.

async function apiGet(action, params) {
  const qs = params ? "?" + new URLSearchParams(params).toString() : "";
  const res = await fetch("/api/" + action + qs);
  return res.json();
}

async function apiPost(action, body) {
  const res = await fetch("/api/" + action, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body || {})
  });
  return res.json();
}

// ---- Authenticated variants (attach a Bearer session token) ----

function authGet(action, params, token) {
  const qs = params ? "?" + new URLSearchParams(params).toString() : "";
  return fetch("/api/" + action + qs, { headers: { Authorization: "Bearer " + token } }).then(res => res.json());
}

function authPost(action, body, token) {
  return fetch("/api/" + action, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: "Bearer " + token },
    body: JSON.stringify(body || {})
  }).then(res => res.json());
}

// ---- Student session (persisted across visits in localStorage) ----

const STUDENT_SESSION_KEY = "studentSession";

function getStudentSession() {
  try { return JSON.parse(localStorage.getItem(STUDENT_SESSION_KEY) || "null"); } catch (e) { return null; }
}
function setStudentSession(sess) { localStorage.setItem(STUDENT_SESSION_KEY, JSON.stringify(sess)); }
function clearStudentSession() { localStorage.removeItem(STUDENT_SESSION_KEY); }

function studentApiGet(action, params) {
  const sess = getStudentSession();
  if (!sess) return Promise.reject(new Error("Not logged in"));
  return authGet(action, params, sess.token);
}
function studentApiPost(action, body) {
  const sess = getStudentSession();
  if (!sess) return Promise.reject(new Error("Not logged in"));
  return authPost(action, body, sess.token);
}

// Redirects to the login page (remembering where to come back to) if no student is logged in.
function requireStudentLogin() {
  const sess = getStudentSession();
  if (!sess) {
    location.href = "student-login.html?next=" + encodeURIComponent(location.pathname + location.search);
    return null;
  }
  return sess;
}

// ---- Admin session (kept only for this browser session) ----

const ADMIN_SESSION_KEY = "adminSession";

function getAdminSession() {
  try { return JSON.parse(sessionStorage.getItem(ADMIN_SESSION_KEY) || "null"); } catch (e) { return null; }
}
function setAdminSession(sess) { sessionStorage.setItem(ADMIN_SESSION_KEY, JSON.stringify(sess)); }
function clearAdminSession() { sessionStorage.removeItem(ADMIN_SESSION_KEY); }

function adminApiGet(action, params) {
  const sess = getAdminSession();
  if (!sess) return Promise.reject(new Error("Not logged in"));
  return authGet(action, params, sess.token);
}
function adminApiPost(action, body) {
  const sess = getAdminSession();
  if (!sess) return Promise.reject(new Error("Not logged in"));
  return authPost(action, body, sess.token);
}

function escapeHtml(s) {
  const d = document.createElement("div");
  d.textContent = s == null ? "" : String(s);
  return d.innerHTML;
}

// Renders the small "logged in as ..." / "Admin" nav bit shared by every page's topbar.
async function renderNavStatus(elId) {
  const el = document.getElementById(elId);
  if (!el) return;
  const studentSess = getStudentSession();
  if (studentSess) {
    el.innerHTML = 'Hi, ' + escapeHtml(studentSess.name) + ' &nbsp;·&nbsp; ' +
      '<a href="student-dashboard.html">My grades</a> &nbsp;·&nbsp; <a href="#" id="navLogout">Log out</a>';
    document.getElementById("navLogout").addEventListener("click", (e) => {
      e.preventDefault(); clearStudentSession(); location.reload();
    });
  } else {
    el.innerHTML = '<a href="student-login.html">Student login</a>';
  }
}
