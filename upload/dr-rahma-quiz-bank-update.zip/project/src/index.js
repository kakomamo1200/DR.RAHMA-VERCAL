// Dr. Rahma Quiz Bank — Worker
//
// Data model (Cloudflare KV, binding QUIZ_DATA):
//   catalog                      -> [{subjectSlug, subjectName, description, quizzes:[{id,title,description,durationMin,questionCount,totalPoints}]}]
//   quiz:{quizId}                -> [{title, choices:[...], correct, points, help}, ...]   (ANSWER KEY — never sent to students directly)
//   student:{username}           -> {username, displayUsername, name, email, salt, hash, encPassword, createdAt}
//   session:{token}              -> {role:"admin"|"student", username?, expires}  (KV expirationTtl used)
//   attempt:{attemptId}          -> {attemptId, username, name, quizId, quizTitle, startedAt, durationMin,
//                                    answers, submitted, auto, score, total, percent, submittedAt}
//   openAttempts                 -> [attemptId, ...]           (in-progress attempts, swept periodically)
//   studentAttempt:{username}:{quizId} -> attemptId             (one attempt per student per quiz)
//   studentResults:{username}    -> [{attemptId, quizId, quizTitle, score, total, percent, auto, submittedAt}, ...]
//   results_index                -> same shape as above but global, for the admin dashboard
//
// Grading and timing are fully server-authoritative: the answer key is only ever loaded
// server-side, the score is always computed on the server from stored answers, and the
// countdown students see is derived from a server-recorded startedAt.
//
// Concurrency: every mutation that decides "has this student already started / already
// submitted this quiz?" is routed through the AttemptCoordinator Durable Object (see
// below), keyed by `${username}:${quizId}`. Cloudflare KV has no real transactions, so
// two browser tabs racing to submit at the same instant could otherwise both read
// "not submitted yet" before either write landed, producing a duplicate graded result.
// The Durable Object processes every request for a given student+quiz strictly one at a
// time (via an in-memory promise queue — see AttemptCoordinator.fetch), so only one of
// the two racing requests can ever win; the other is told the attempt is already
// submitted and gets back the authoritative score instead of grading a second time.

const SESSION_TTL_ADMIN = 60 * 60 * 12;   // 12h
const SESSION_TTL_STUDENT = 60 * 60 * 24 * 14; // 14 days
const LATE_GRACE_SEC = 10;       // network latency grace before a submit counts as "late"
const SWEEP_GRACE_SEC = 60;      // how long past the deadline an abandoned attempt waits before auto-finalizing

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json" }
  });
}
function err(msg, status = 400) { return json({ error: msg }, status); }

// ---------- crypto helpers ----------
function bufToHex(buf) {
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
}
function bufToBase64(buf) {
  let s = "";
  const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}
function base64ToBuf(b64) {
  const s = atob(b64);
  const bytes = new Uint8Array(s.length);
  for (let i = 0; i < s.length; i++) bytes[i] = s.charCodeAt(i);
  return bytes;
}
async function hashPassword(password, saltHex) {
  const enc = new TextEncoder();
  const data = enc.encode(saltHex + ":" + password);
  const digest = await crypto.subtle.digest("SHA-256", data);
  return bufToHex(digest);
}
function newSalt() { return bufToHex(crypto.getRandomValues(new Uint8Array(16))); }
function newToken() { return crypto.randomUUID().replace(/-/g, "") + crypto.randomUUID().replace(/-/g, ""); }

// ---- Reversible password storage, used ONLY for the "forgot password" email flow. ----
// This is intentionally separate from the SHA-256 login hash above, which stays
// one-way. The recovery key never leaves the server and is provided as a secret
// (`wrangler secret put RECOVERY_KEY`) — a base64-encoded 32-byte AES-GCM key. If it's
// not configured, registration still works but recovery email sending is disabled.
async function getRecoveryKey(env) {
  if (!env.RECOVERY_KEY) return null;
  const raw = base64ToBuf(env.RECOVERY_KEY);
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}
async function encryptPassword(env, password) {
  const key = await getRecoveryKey(env);
  if (!key) return null;
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(password));
  return bufToBase64(iv) + "." + bufToBase64(cipher);
}
async function decryptPassword(env, blob) {
  const key = await getRecoveryKey(env);
  if (!key || !blob) return null;
  const [ivB64, cipherB64] = blob.split(".");
  if (!ivB64 || !cipherB64) return null;
  const iv = base64ToBuf(ivB64);
  const cipherBuf = base64ToBuf(cipherB64);
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, cipherBuf);
  return new TextDecoder().decode(plain);
}

// ---------- outbound email (Resend) ----------
// Requires two secrets: RESEND_API_KEY (from resend.com) and optionally RESEND_FROM
// (a verified sender, e.g. "Dr. Rahma Quiz Bank <noreply@yourdomain.com>"). Falls back
// to Resend's shared test sender if RESEND_FROM isn't set, which only works for the
// account owner's own inbox — fine for testing, not for real use with students.
function escapeForEmail(s) {
  return String(s == null ? "" : s).replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
}
async function sendRecoveryEmail(env, toEmail, name, username, password) {
  if (!env.RESEND_API_KEY) throw new Error("Email service is not configured (missing RESEND_API_KEY).");
  const from = env.RESEND_FROM || "Dr. Rahma Quiz Bank <onboarding@resend.dev>";
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: "Bearer " + env.RESEND_API_KEY, "Content-Type": "application/json" },
    body: JSON.stringify({
      from,
      to: [toEmail],
      subject: "Your Dr. Rahma Quiz Bank login",
      html:
        "<p>Hi " + escapeForEmail(name) + ",</p>" +
        "<p>You (or someone using your email) asked to recover your Dr. Rahma Quiz Bank login. Here it is:</p>" +
        "<p>Username: <b>" + escapeForEmail(username) + "</b><br>Password: <b>" + escapeForEmail(password) + "</b></p>" +
        "<p>If you didn't request this, you can ignore this email — your account is unchanged.</p>"
    })
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error("Email provider rejected the request (" + res.status + "): " + detail);
  }
}

// ---------- session helpers ----------
async function getSession(env, request) {
  const auth = request.headers.get("Authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : null;
  if (!token) return null;
  const raw = await env.QUIZ_DATA.get("session:" + token);
  if (!raw) return null;
  try { return { ...JSON.parse(raw), token }; } catch (e) { return null; }
}
async function requireAdmin(env, request) {
  const sess = await getSession(env, request);
  if (!sess || sess.role !== "admin") return null;
  return sess;
}
async function requireStudent(env, request) {
  const sess = await getSession(env, request);
  if (!sess || sess.role !== "student") return null;
  return sess;
}

// ---------- catalog / KV helpers ----------
async function getCatalog(env) {
  const raw = await env.QUIZ_DATA.get("catalog");
  return raw ? JSON.parse(raw) : [];
}
async function saveCatalog(env, catalog) { await env.QUIZ_DATA.put("catalog", JSON.stringify(catalog)); }

function findQuizMeta(catalog, quizId) {
  for (const s of catalog) {
    const q = s.quizzes.find(item => item.id === quizId);
    if (q) return { subject: s, meta: q };
  }
  return null;
}

async function pushCapped(env, key, entry, cap) {
  const raw = await env.QUIZ_DATA.get(key);
  const arr = raw ? JSON.parse(raw) : [];
  arr.push(entry);
  if (cap && arr.length > cap) arr.splice(0, arr.length - cap);
  await env.QUIZ_DATA.put(key, JSON.stringify(arr));
}

// ================= AUTH: ADMIN =================

async function handleAdminLogin(env, body) {
  const { user, pass } = body;
  if (typeof env.ADMIN_USER !== "string" || typeof env.ADMIN_PASS !== "string") return err("Server not configured", 500);
  if (user !== env.ADMIN_USER || pass !== env.ADMIN_PASS) return json({ ok: false });
  const token = newToken();
  await env.QUIZ_DATA.put("session:" + token, JSON.stringify({ role: "admin", expires: Date.now() + SESSION_TTL_ADMIN * 1000 }), { expirationTtl: SESSION_TTL_ADMIN });
  return json({ ok: true, token });
}

// ================= AUTH: STUDENT =================

function validUsername(u) { return typeof u === "string" && /^[a-zA-Z0-9_.-]{3,32}$/.test(u); }
function validEmail(e) { return typeof e === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

async function handleStudentRegister(env, body) {
  const username = (body.username || "").trim();
  const password = body.password || "";
  const name = (body.name || "").trim();
  const email = (body.email || "").trim();
  if (!validUsername(username)) return err("Username must be 3-32 characters, letters/numbers only, no spaces.");
  if (!name) return err("Enter your full name.");
  if (!validEmail(email)) return err("Enter a valid email address — it's needed to recover your password later.");
  if (password.length < 4) return err("Password must be at least 4 characters.");
  const existing = await env.QUIZ_DATA.get("student:" + username.toLowerCase());
  if (existing) return err("That username is already taken.");
  const salt = newSalt();
  const hash = await hashPassword(password, salt);
  const encPassword = await encryptPassword(env, password); // null if RECOVERY_KEY isn't configured
  const record = {
    username: username.toLowerCase(), displayUsername: username, name, email,
    salt, hash, encPassword, createdAt: new Date().toISOString()
  };
  await env.QUIZ_DATA.put("student:" + username.toLowerCase(), JSON.stringify(record));
  const token = newToken();
  await env.QUIZ_DATA.put("session:" + token, JSON.stringify({ role: "student", username: username.toLowerCase(), expires: Date.now() + SESSION_TTL_STUDENT * 1000 }), { expirationTtl: SESSION_TTL_STUDENT });
  return json({ ok: true, token, name, username: record.displayUsername });
}

async function handleStudentLogin(env, body) {
  const username = (body.username || "").trim().toLowerCase();
  const password = body.password || "";
  const raw = await env.QUIZ_DATA.get("student:" + username);
  if (!raw) return json({ ok: false });
  const record = JSON.parse(raw);
  const hash = await hashPassword(password, record.salt);
  if (hash !== record.hash) return json({ ok: false });
  const token = newToken();
  await env.QUIZ_DATA.put("session:" + token, JSON.stringify({ role: "student", username: record.username, expires: Date.now() + SESSION_TTL_STUDENT * 1000 }), { expirationTtl: SESSION_TTL_STUDENT });
  return json({ ok: true, token, name: record.name, username: record.displayUsername });
}

// Deliberately returns the same generic message whether or not the account/email
// exists, so this endpoint can't be used to enumerate registered usernames.
const FORGOT_GENERIC_MESSAGE = "If that account exists, we've emailed the password to the address on file.";

async function handleForgotPassword(env, body) {
  const username = (body.username || "").trim().toLowerCase();
  if (!username) return err("Enter your username.");
  const raw = await env.QUIZ_DATA.get("student:" + username);
  if (raw) {
    try {
      const record = JSON.parse(raw);
      if (record.email) {
        // Older accounts created before this feature shipped won't have encPassword —
        // nothing we can do for those except tell the student to make a new account.
        const password = record.encPassword ? await decryptPassword(env, record.encPassword) : null;
        if (password) await sendRecoveryEmail(env, record.email, record.name, record.displayUsername, password);
      }
    } catch (e) {
      // Swallow errors here on purpose (bad RECOVERY_KEY, Resend outage, etc.) — we
      // still return the generic message below rather than leaking internal state,
      // but log server-side via the thrown detail for the admin to notice in tail logs.
      console.error("forgotPassword failed:", e);
    }
  }
  return json({ ok: true, message: FORGOT_GENERIC_MESSAGE });
}

async function handleWhoAmI(env, request) {
  const sess = await getSession(env, request);
  if (!sess) return json({ role: null });
  if (sess.role === "student") {
    const raw = await env.QUIZ_DATA.get("student:" + sess.username);
    const rec = raw ? JSON.parse(raw) : null;
    return json({ role: "student", username: rec ? rec.displayUsername : sess.username, name: rec ? rec.name : "" });
  }
  return json({ role: "admin" });
}

// ================= PUBLIC CATALOG =================

async function handleCatalogGet(env) {
  return json(await getCatalog(env));
}

// ================= STUDENT: TAKE QUIZ =================

function sanitizeQuestions(questions) {
  // Never send the answer key to the browser before submission.
  return questions.map(q => ({ title: q.title, choices: q.choices, points: q.points || 1, help: q.help || "" }));
}

async function finalizeAttempt(env, attempt, quizQuestions, answers, autoFlag) {
  let score = 0;
  const total = quizQuestions.reduce((s, q) => s + (q.points || 1), 0);
  quizQuestions.forEach((q, i) => { if (answers[i] === q.correct) score += (q.points || 1); });
  const percent = total > 0 ? Math.round((score / total) * 100) : 0;

  attempt.submitted = true;
  attempt.answers = answers;
  attempt.score = score;
  attempt.total = total;
  attempt.percent = percent;
  attempt.auto = !!autoFlag;
  attempt.submittedAt = new Date().toISOString();
  attempt.durationTakenSec = Math.round((Date.parse(attempt.submittedAt) - attempt.startedAt) / 1000);

  await env.QUIZ_DATA.put("attempt:" + attempt.attemptId, JSON.stringify(attempt));

  const summary = {
    attemptId: attempt.attemptId, username: attempt.username, name: attempt.name,
    quizId: attempt.quizId, quizTitle: attempt.quizTitle, score, total, percent,
    auto: attempt.auto, submittedAt: attempt.submittedAt, durationTakenSec: attempt.durationTakenSec
  };
  // Caps are a safety valve against the ~25MB-per-key KV limit, not a real limit for
  // normal use (a school year of quizzes is nowhere near this many entries).
  await pushCapped(env, "studentResults:" + attempt.username, summary, 2000);
  await pushCapped(env, "results_index", summary, 20000);

  // remove from the open-attempts sweep list
  const rawOpen = await env.QUIZ_DATA.get("openAttempts");
  const open = rawOpen ? JSON.parse(rawOpen) : [];
  const idx = open.indexOf(attempt.attemptId);
  if (idx >= 0) { open.splice(idx, 1); await env.QUIZ_DATA.put("openAttempts", JSON.stringify(open)); }

  return attempt;
}

// ---- these two used to live directly in the request handlers; they now run *inside*
// the AttemptCoordinator Durable Object so the "check, then write" logic for a given
// student+quiz can never be split across two concurrent tab requests. ----

async function doStart(env, { username, name, quizId, quizMeta }) {
  const existingId = await env.QUIZ_DATA.get("studentAttempt:" + username + ":" + quizId);
  if (existingId) {
    const raw = await env.QUIZ_DATA.get("attempt:" + existingId);
    if (raw) {
      const attempt = JSON.parse(raw);
      if (attempt.submitted) {
        return json({ status: "already_submitted", attemptId: attempt.attemptId, result: { score: attempt.score, total: attempt.total, percent: attempt.percent, auto: attempt.auto } });
      }
      const questionsRaw = await env.QUIZ_DATA.get("quiz:" + quizId);
      const questions = questionsRaw ? JSON.parse(questionsRaw) : [];
      const elapsedSec = (Date.now() - attempt.startedAt) / 1000;
      if (elapsedSec > attempt.durationMin * 60 + LATE_GRACE_SEC) {
        const finalized = await finalizeAttempt(env, attempt, questions, attempt.answers || questions.map(() => null), true);
        return json({ status: "already_submitted", attemptId: finalized.attemptId, result: { score: finalized.score, total: finalized.total, percent: finalized.percent, auto: true } });
      }
      return json({
        status: "resumed", attemptId: attempt.attemptId, serverNow: Date.now(),
        startedAt: attempt.startedAt, durationMin: attempt.durationMin,
        title: quizMeta.title, description: quizMeta.description || "",
        answers: attempt.answers || questions.map(() => null),
        questions: sanitizeQuestions(questions)
      });
    }
  }

  const questionsRaw = await env.QUIZ_DATA.get("quiz:" + quizId);
  const questions = questionsRaw ? JSON.parse(questionsRaw) : [];
  if (!questions.length) return err("This quiz doesn't have any questions yet.", 404);

  const attemptId = crypto.randomUUID();
  const attempt = {
    attemptId, username, name, quizId, quizTitle: quizMeta.title, startedAt: Date.now(),
    durationMin: quizMeta.durationMin || 40, answers: questions.map(() => null), submitted: false
  };
  await env.QUIZ_DATA.put("attempt:" + attemptId, JSON.stringify(attempt));
  await env.QUIZ_DATA.put("studentAttempt:" + username + ":" + quizId, attemptId);
  const rawOpen = await env.QUIZ_DATA.get("openAttempts");
  const open = rawOpen ? JSON.parse(rawOpen) : [];
  open.push(attemptId);
  await env.QUIZ_DATA.put("openAttempts", JSON.stringify(open));

  return json({
    status: "started", attemptId, serverNow: Date.now(),
    startedAt: attempt.startedAt, durationMin: attempt.durationMin,
    title: quizMeta.title, description: quizMeta.description || "",
    answers: attempt.answers, questions: sanitizeQuestions(questions)
  });
}

async function doSubmit(env, { username, attemptId, answers, auto }) {
  const raw = await env.QUIZ_DATA.get("attempt:" + attemptId);
  if (!raw) return err("Attempt not found", 404);
  const attempt = JSON.parse(raw);
  if (attempt.username !== username) return err("Unauthorized", 401);
  if (attempt.submitted) {
    return json({ status: "ok", result: { score: attempt.score, total: attempt.total, percent: attempt.percent, auto: attempt.auto } });
  }
  const questionsRaw = await env.QUIZ_DATA.get("quiz:" + attempt.quizId);
  const questions = questionsRaw ? JSON.parse(questionsRaw) : [];
  const finalAnswers = Array.isArray(answers) ? answers : (attempt.answers || questions.map(() => null));
  const elapsedSec = (Date.now() - attempt.startedAt) / 1000;
  const isLate = elapsedSec > attempt.durationMin * 60 + LATE_GRACE_SEC;
  const finalized = await finalizeAttempt(env, attempt, questions, finalAnswers, !!auto || isLate);
  return json({ status: "ok", result: { score: finalized.score, total: finalized.total, percent: finalized.percent, auto: finalized.auto } });
}

// ---------- Durable Object stub helper ----------
function coordinatorFor(env, username, quizId) {
  const id = env.ATTEMPT_COORDINATOR.idFromName(username + ":" + quizId);
  return env.ATTEMPT_COORDINATOR.get(id);
}

async function handleStartAttempt(env, request, body) {
  const sess = await requireStudent(env, request);
  if (!sess) return err("Log in first to start the quiz.", 401);
  const quizId = body.quizId;
  if (!quizId) return err("Missing quizId");

  const catalog = await getCatalog(env);
  const found = findQuizMeta(catalog, quizId);
  if (!found) return err("This quiz doesn't exist.", 404);

  const name = await getStudentName(env, sess.username);
  const stub = coordinatorFor(env, sess.username, quizId);
  const res = await stub.fetch("https://coordinator/start", {
    method: "POST",
    body: JSON.stringify({ username: sess.username, name, quizId, quizMeta: found.meta })
  });
  return res;
}

// Lightweight check used by the quiz landing page: tells the client whether this
// student already has an attempt for this quiz WITHOUT starting a new one (starting
// the timer must only ever happen when the student presses "Start").
async function handleAttemptStatus(env, request, url) {
  const sess = await requireStudent(env, request);
  if (!sess) return err("Unauthorized", 401);
  const quizId = url.searchParams.get("quizId");
  const existingId = await env.QUIZ_DATA.get("studentAttempt:" + sess.username + ":" + quizId);
  if (!existingId) return json({ status: "none" });
  const raw = await env.QUIZ_DATA.get("attempt:" + existingId);
  if (!raw) return json({ status: "none" });
  const attempt = JSON.parse(raw);
  if (attempt.submitted) return json({ status: "submitted", attemptId: attempt.attemptId });
  const elapsedSec = (Date.now() - attempt.startedAt) / 1000;
  if (elapsedSec > attempt.durationMin * 60 + LATE_GRACE_SEC) {
    // Time was already up before the student came back to this tab — close it out now
    // (grading with whatever was last autosaved) so a result is always recorded. Routed
    // through the coordinator so this can't race a genuine in-flight submit.
    const stub = coordinatorFor(env, sess.username, quizId);
    const res = await stub.fetch("https://coordinator/submit", {
      method: "POST",
      body: JSON.stringify({ username: sess.username, attemptId: attempt.attemptId, answers: attempt.answers, auto: true })
    });
    const data = await res.json();
    if (data.error) return json({ status: "none" });
    return json({ status: "submitted", attemptId: attempt.attemptId });
  }
  return json({ status: "in_progress", attemptId: attempt.attemptId });
}

async function getStudentName(env, username) {
  const raw = await env.QUIZ_DATA.get("student:" + username);
  if (!raw) return username;
  return JSON.parse(raw).name || username;
}

async function loadOpenAttempt(env, sess, attemptId) {
  const raw = await env.QUIZ_DATA.get("attempt:" + attemptId);
  if (!raw) return null;
  const attempt = JSON.parse(raw);
  if (attempt.username !== sess.username) return null;
  return attempt;
}

async function handleSaveProgress(env, request, body) {
  const sess = await requireStudent(env, request);
  if (!sess) return err("Unauthorized", 401);
  const attempt = await loadOpenAttempt(env, sess, body.attemptId);
  if (!attempt) return err("Attempt not found", 404);
  if (attempt.submitted) return json({ status: "already_submitted" });
  const elapsedSec = (Date.now() - attempt.startedAt) / 1000;
  if (elapsedSec > attempt.durationMin * 60 + LATE_GRACE_SEC) return json({ status: "expired" });
  // Autosave doesn't need the coordinator: worst case with two tabs is "last write
  // wins" on the answer array, which is harmless (no grading decision happens here).
  attempt.answers = Array.isArray(body.answers) ? body.answers : attempt.answers;
  await env.QUIZ_DATA.put("attempt:" + attempt.attemptId, JSON.stringify(attempt));
  return json({ status: "saved" });
}

async function handleSubmitAttempt(env, request, body) {
  const sess = await requireStudent(env, request);
  if (!sess) return err("Unauthorized", 401);
  const attempt = await loadOpenAttempt(env, sess, body.attemptId);
  if (!attempt) return err("Attempt not found", 404);
  const stub = coordinatorFor(env, sess.username, attempt.quizId);
  const res = await stub.fetch("https://coordinator/submit", {
    method: "POST",
    body: JSON.stringify({ username: sess.username, attemptId: attempt.attemptId, answers: body.answers, auto: !!body.auto })
  });
  return res;
}

async function handleAttemptReview(env, request, url) {
  const sess = await requireStudent(env, request);
  if (!sess) return err("Unauthorized", 401);
  const attemptId = url.searchParams.get("attemptId");
  const raw = await env.QUIZ_DATA.get("attempt:" + attemptId);
  if (!raw) return err("Not found", 404);
  const attempt = JSON.parse(raw);
  if (attempt.username !== sess.username) return err("Unauthorized", 401);
  if (!attempt.submitted) return err("Not submitted yet", 400);
  const questionsRaw = await env.QUIZ_DATA.get("quiz:" + attempt.quizId);
  const questions = questionsRaw ? JSON.parse(questionsRaw) : [];
  return json({ quizTitle: attempt.quizTitle, score: attempt.score, total: attempt.total, percent: attempt.percent, auto: attempt.auto, answers: attempt.answers, questions });
}

async function handleMyResults(env, request) {
  const sess = await requireStudent(env, request);
  if (!sess) return err("Unauthorized", 401);
  const raw = await env.QUIZ_DATA.get("studentResults:" + sess.username);
  const list = raw ? JSON.parse(raw) : [];
  list.reverse();
  return json(list);
}

// ================= SWEEP: FINALIZE ABANDONED ATTEMPTS =================

async function sweepOpenAttempts(env) {
  const rawOpen = await env.QUIZ_DATA.get("openAttempts");
  const open = rawOpen ? JSON.parse(rawOpen) : [];
  if (!open.length) return { swept: 0 };
  let swept = 0;
  for (const attemptId of open.slice()) {
    const raw = await env.QUIZ_DATA.get("attempt:" + attemptId);
    if (!raw) continue;
    const attempt = JSON.parse(raw);
    if (attempt.submitted) continue;
    const elapsedSec = (Date.now() - attempt.startedAt) / 1000;
    if (elapsedSec > attempt.durationMin * 60 + SWEEP_GRACE_SEC) {
      // Routed through the same coordinator as a live submit, so the cron sweep can
      // never grade an attempt at the same moment a student's own tab is submitting it.
      const stub = coordinatorFor(env, attempt.username, attempt.quizId);
      const res = await stub.fetch("https://coordinator/submit", {
        method: "POST",
        body: JSON.stringify({ username: attempt.username, attemptId, answers: attempt.answers, auto: true })
      });
      const data = await res.json();
      if (!data.error) swept++;
    }
  }
  return { swept };
}

// ================= ADMIN: QUIZ / SUBJECT MANAGEMENT =================

async function handleAddSubject(env, request, body) {
  if (!(await requireAdmin(env, request))) return err("Unauthorized", 401);
  const subjectName = (body.subjectName || "").trim();
  if (!subjectName) return err("Type a subject name.");
  const subjectSlug = (body.subjectSlug || subjectName).trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
  if (!subjectSlug) return err("Invalid subject name.");
  const catalog = await getCatalog(env);
  if (catalog.some(s => s.subjectSlug === subjectSlug)) return err("Subject already exists.");
  catalog.push({ subjectSlug, subjectName, description: (body.description || "").trim(), quizzes: [] });
  await saveCatalog(env, catalog);
  return json({ status: "ok", subjectSlug });
}

async function handleEditSubject(env, request, body) {
  if (!(await requireAdmin(env, request))) return err("Unauthorized", 401);
  const catalog = await getCatalog(env);
  const subject = catalog.find(s => s.subjectSlug === body.subjectSlug);
  if (!subject) return err("Not found", 404);
  if (typeof body.subjectName === "string" && body.subjectName.trim()) subject.subjectName = body.subjectName.trim();
  if (typeof body.description === "string") subject.description = body.description.trim();
  await saveCatalog(env, catalog);
  return json({ status: "ok" });
}

async function handleAddQuiz(env, request, body) {
  if (!(await requireAdmin(env, request))) return err("Unauthorized", 401);
  const q = body.quiz;
  if (!q || !q.id || !Array.isArray(q.questions) || !q.questions.length) return err("Missing quiz data");
  const catalog = await getCatalog(env);
  const subject = catalog.find(s => s.subjectSlug === body.subjectSlug);
  if (!subject) return err("Pick an existing subject (add one from the Subjects page first).", 400);
  const totalPoints = q.questions.reduce((sum, item) => sum + (item.points || 1), 0);
  const meta = { id: q.id, title: q.title, description: q.description || "", durationMin: q.durationMin, questionCount: q.questions.length, totalPoints };
  const existingIdx = subject.quizzes.findIndex(item => item.id === q.id);
  if (existingIdx >= 0) subject.quizzes[existingIdx] = meta;
  else subject.quizzes.push(meta);
  await saveCatalog(env, catalog);
  await env.QUIZ_DATA.put("quiz:" + q.id, JSON.stringify(q.questions));
  return json({ status: "ok" });
}

async function handleDeleteQuiz(env, request, body) {
  if (!(await requireAdmin(env, request))) return err("Unauthorized", 401);
  const catalog = await getCatalog(env);
  const subject = catalog.find(s => s.subjectSlug === body.subjectSlug);
  if (subject) {
    subject.quizzes = subject.quizzes.filter(q => q.id !== body.quizId);
    await saveCatalog(env, catalog);
  }
  await env.QUIZ_DATA.delete("quiz:" + body.quizId);
  return json({ status: "ok" });
}

async function handleDeleteSubject(env, request, body) {
  if (!(await requireAdmin(env, request))) return err("Unauthorized", 401);
  const catalog = await getCatalog(env);
  const subject = catalog.find(s => s.subjectSlug === body.subjectSlug);
  const remaining = catalog.filter(s => s.subjectSlug !== body.subjectSlug);
  if (subject) {
    for (const q of subject.quizzes) await env.QUIZ_DATA.delete("quiz:" + q.id);
  }
  await saveCatalog(env, remaining);
  return json({ status: "ok" });
}

// ================= ADMIN: RESULTS DASHBOARD =================

async function handleResults(env, request) {
  if (!(await requireAdmin(env, request))) return err("Unauthorized", 401);
  const raw = await env.QUIZ_DATA.get("results_index");
  const index = raw ? JSON.parse(raw) : [];
  index.reverse();
  return json(index);
}

async function handleResultDetail(env, request, body) {
  if (!(await requireAdmin(env, request))) return err("Unauthorized", 401);
  const raw = await env.QUIZ_DATA.get("attempt:" + body.attemptId);
  if (!raw) return err("Not found", 404);
  const attempt = JSON.parse(raw);
  const quizRaw = await env.QUIZ_DATA.get("quiz:" + attempt.quizId);
  const questions = quizRaw ? JSON.parse(quizRaw) : [];
  return json({ name: attempt.name, quizTitle: attempt.quizTitle, answers: attempt.answers, questions });
}

async function handleAdminSweep(env, request) {
  if (!(await requireAdmin(env, request))) return err("Unauthorized", 401);
  const result = await sweepOpenAttempts(env);
  return json({ status: "ok", ...result });
}

// ================= DURABLE OBJECT: AttemptCoordinator =================
//
// One instance per (student, quiz) pair — see coordinatorFor() above, which derives the
// instance from `${username}:${quizId}`. Cloudflare guarantees a given Durable Object
// id always resolves to the same single instance, and this class explicitly chains every
// incoming fetch() onto an in-memory promise queue, so two "start" or "submit" calls
// that land on the same instance milliseconds apart are still executed one after the
// other — never interleaved — regardless of how many `await`s the KV reads/writes below
// take. That's what actually closes the double-tab race described in the README; the
// underlying KV reads/writes are unchanged from before.
export class AttemptCoordinator {
  constructor(state, env) {
    this.env = env;
    this.chain = Promise.resolve();
  }

  fetch(request) {
    const run = this.chain.then(() => this.handle(request));
    // Keep the chain alive even if this request throws, so later requests aren't stuck.
    this.chain = run.catch(() => {});
    return run;
  }

  async handle(request) {
    let body;
    try { body = await request.json(); } catch (e) { return err("Invalid JSON"); }
    const path = new URL(request.url).pathname;
    try {
      if (path === "/start") return await doStart(this.env, body);
      if (path === "/submit") return await doSubmit(this.env, body);
      return err("Unknown coordinator action", 404);
    } catch (e) {
      return json({ error: "Coordinator error", detail: String(e) }, 500);
    }
  }
}

// ================= ROUTER =================

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/api/")) {
      const action = url.pathname.slice(5);
      try {
        if (request.method === "GET" && action === "catalog") return await handleCatalogGet(env);
        if (request.method === "GET" && action === "whoAmI") return await handleWhoAmI(env, request);
        if (request.method === "GET" && action === "myResults") return await handleMyResults(env, request);
        if (request.method === "GET" && action === "attemptReview") return await handleAttemptReview(env, request, url);
        if (request.method === "GET" && action === "attemptStatus") return await handleAttemptStatus(env, request, url);

        if (request.method === "POST") {
          let body;
          try { body = await request.json(); } catch (e) { return err("Invalid JSON"); }
          if (action === "adminLogin") return await handleAdminLogin(env, body);
          if (action === "studentRegister") return await handleStudentRegister(env, body);
          if (action === "studentLogin") return await handleStudentLogin(env, body);
          if (action === "forgotPassword") return await handleForgotPassword(env, body);

          if (action === "startAttempt") return await handleStartAttempt(env, request, body);
          if (action === "saveProgress") return await handleSaveProgress(env, request, body);
          if (action === "submitAttempt") return await handleSubmitAttempt(env, request, body);

          if (action === "results") return await handleResults(env, request);
          if (action === "resultDetail") return await handleResultDetail(env, request, body);
          if (action === "addSubject") return await handleAddSubject(env, request, body);
          if (action === "editSubject") return await handleEditSubject(env, request, body);
          if (action === "addQuiz") return await handleAddQuiz(env, request, body);
          if (action === "deleteQuiz") return await handleDeleteQuiz(env, request, body);
          if (action === "deleteSubject") return await handleDeleteSubject(env, request, body);
          if (action === "adminSweep") return await handleAdminSweep(env, request);
        }
        return err("Unknown API route", 404);
      } catch (e) {
        return json({ error: "Server error", detail: String(e) }, 500);
      }
    }

    return env.ASSETS.fetch(request);
  },

  // Runs on the cron schedule declared in wrangler.jsonc — finalizes any quiz
  // attempt whose timer ran out but whose tab was closed before it could submit,
  // so a grade always gets recorded.
  async scheduled(event, env, ctx) {
    ctx.waitUntil(sweepOpenAttempts(env));
  }
};
