# Dr. Rahma Quiz Bank — Update

## What changed in this update

**1) Whole site translated to English**
- Every page (`index.html`, `subject.html`, `quiz-runner.html`, the three admin pages,
  `student-login.html`, `student-dashboard.html`) now ships in English, `lang="en"
  dir="ltr"`, including the small "accent stripe" CSS that was written for
  right-to-left layout and has been flipped to the left side for LTR reading.
- `catalog` and `quiz:*` data (subjects, quizzes, question text) are untouched — this
  update only changes the app's own UI strings, not content you've entered. Any
  subject/quiz titles you typed in Arabic will still display in Arabic; only the
  buttons, labels, and messages around them are now English.

**2) "Forgot password" via email**
- Registration now asks for an email address (required) alongside username/password.
- The password is stored two ways: the existing one-way SHA-256+salt hash used to
  check logins (unchanged), plus a *reversible* AES-GCM encrypted copy used only by
  the recovery flow. The encryption key is a server secret that never reaches the
  browser.
- A new "Forgot your password?" link on the login page calls `POST /api/forgotPassword`
  with just a username. The server looks up the account, decrypts the stored password,
  and emails it (via [Resend](https://resend.com)) to the address on file. The response
  is the same generic message whether or not the account exists, so this endpoint can't
  be used to check which usernames are registered.
- **Accounts created before this update** have no email on file and no recoverable
  password — recovery will silently do nothing for them. There's no way around that
  without asking those students to re-register; a heads-up in class is the simplest fix.

**3) Fixed the double-tab / double-submit race**
- Previously, `submitAttempt` (and the timeout/sweep paths) read the attempt from KV,
  checked `if (attempt.submitted)`, and only then wrote the graded result. Cloudflare
  KV has no real transactions, so two tabs submitting at the exact same instant could
  both pass that check before either write landed, in rare cases logging two rows for
  one exam.
- This is now closed with a Durable Object, `AttemptCoordinator` (see `src/index.js`
  and the `durable_objects` block in `wrangler.jsonc`). One DO instance exists per
  `(student, quiz)` pair. Every request that makes a "have I already started / already
  submitted?" decision — starting a quiz, submitting it, the timeout auto-submit, and
  the cron sweep — is routed through that instance's `fetch()`, which explicitly chains
  incoming requests onto an in-memory promise queue so they execute one at a time, in
  order, even though the KV reads/writes inside each one are still asynchronous. Two
  tabs racing to submit now always resolve to exactly one graded attempt; the loser
  gets back the same authoritative score instead of grading a second time.
- Autosave (`saveProgress`, every 15s) deliberately does **not** go through the
  coordinator — "last write wins" on the answer array is harmless there, since no
  grading decision happens on that path, and adding the extra hop would just slow
  down every keystroke-adjacent save for no benefit.

## Old data (from before either update)

- `catalog` and `quiz:*` keep working unchanged.
- Results recorded before the very first "attempt"-based rewrite (`results_index` /
  `result_detail:*` in the old flat format) still won't show up in the results
  dashboard, for the same reason noted previously: the dashboard reads `attempt:*`
  records, and those old rows never had one. Export them from the old dashboard before
  deploying if you still need them.

## File layout

```
wrangler.jsonc                          → KV + Durable Object bindings, cron trigger
src/index.js                            → Worker (adds AttemptCoordinator DO + email recovery)
quiz-site-cloudflare/
  index.html                            → subject list
  subject.html                          → quizzes in a subject
  quiz-runner.html                      → the exam-taking page
  admin.html                            → dashboard: login + results (now with a clearer
                                           correct/incorrect/unanswered summary per attempt)
  admin-subjects.html                   → dashboard: subjects
  admin-quizzes.html                    → dashboard: quizzes
  student-login.html                    → student login / register / forgot password
  student-dashboard.html                → "My grades"
  site-config.js                        → shared API + session helpers
  style.css                             → shared styles
  quiz_template.xlsx, vendor/*.js       → unchanged
```

## Deploy steps

1. Secrets — the two you already had, plus two new ones for password recovery:
   ```
   wrangler secret put ADMIN_USER
   wrangler secret put ADMIN_PASS
   wrangler secret put RECOVERY_KEY      # base64, 32 random bytes — see below
   wrangler secret put RESEND_API_KEY    # from resend.com
   ```
   Generate `RECOVERY_KEY` locally, e.g.:
   ```
   openssl rand -base64 32
   ```
   Optionally also set `RESEND_FROM` (a verified sender address, e.g.
   `"Dr. Rahma Quiz Bank <noreply@yourdomain.com>"`) via `wrangler secret put RESEND_FROM`
   — without it, recovery emails use Resend's shared test sender, which only delivers
   to the Resend account owner's own inbox and isn't usable for real students.

   If you skip `RECOVERY_KEY` or `RESEND_API_KEY`, registration and login still work
   normally — only the "forgot password" email won't go out (it fails silently from
   the student's point of view, same generic message either way).

2. Deploy:
   ```
   wrangler deploy
   ```
   The first deploy after this update runs the Durable Object migration declared in
   `wrangler.jsonc` automatically — no manual step needed, and it works on the free
   plan.

3. Confirm the cron trigger is active (Cloudflare enables it automatically from
   `wrangler.jsonc`).

## Known limitations (not bugs, just worth knowing)

- Students who registered before this update have no email on file, so "forgot
  password" won't be able to help them — see the "Old data" section above.
- Passwords are stored hashed (for login) **and** separately AES-encrypted (for
  recovery emails) — this is a deliberate trade-off to offer "email me my password"
  rather than the more common "reset link" flow, since it was the explicitly
  requested feature. It means anyone with server-side access to both the KV data and
  the `RECOVERY_KEY` secret could, in principle, recover a student's plaintext
  password. Keep `RECOVERY_KEY` as tightly held as `ADMIN_PASS`.
